package com.example.gondwana_club

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
