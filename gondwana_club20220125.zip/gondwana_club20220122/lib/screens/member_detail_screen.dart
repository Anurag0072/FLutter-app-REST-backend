import 'package:flutter/material.dart';

import '../global_style/style.dart';
import '../member_directory.dart';

class MemberDetailsScreen extends StatefulWidget {
  final MemberDirectory member;

  const MemberDetailsScreen(this.member, {Key?key}) : super(key: key);

  @override
  MemberDetailsState createState() => MemberDetailsState();
}

class MemberDetailsState extends State<MemberDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Member Details'),
        backgroundColor: AppStyle.appBarColor,
      ),
      body: Center(
        child: Column(
          children: [
            const SizedBox(height: 16),
            Icon(
              widget.member.icon,
              size: 100,
            ),
            const SizedBox(height: 16),
            Text(
              'Member Name: ${widget.member.memberName}',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'Member City: ${widget.member.memberCity}',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}