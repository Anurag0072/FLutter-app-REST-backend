import 'package:flutter/material.dart';
import 'package:gondwana_club/global_style/style.dart';

class PrivacyScreen extends StatefulWidget {
  @override
  PrivacyScreenState createState() => PrivacyScreenState();
}

class PrivacyScreenState extends State<PrivacyScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Privacy Policy'),
        backgroundColor: AppStyle.appBarColor,
      ),
    );
  }
}