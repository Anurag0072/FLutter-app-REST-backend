import 'package:flutter/material.dart';
import 'package:gondwana_club/global_style/style.dart';

class YourOrderScreen extends StatefulWidget {
  @override
  YourOrderScreenState createState() => YourOrderScreenState();
}

class YourOrderScreenState extends State<YourOrderScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Orders'),
        backgroundColor: AppStyle.appBarColor,
      ),
    );
  }

}






