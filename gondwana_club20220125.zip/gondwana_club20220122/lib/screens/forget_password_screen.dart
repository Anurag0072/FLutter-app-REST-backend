import 'package:flutter/material.dart';
import '../global_style/style.dart';
import 'reset_password_screen.dart';

class ForgetPasswordScreen extends StatefulWidget {

  @override
  ForgetPasswordState createState() => ForgetPasswordState();
}

class ForgetPasswordState extends State<ForgetPasswordScreen> {
  final formGlobalKey = GlobalKey < FormState > ();
  TextEditingController memberIdController = TextEditingController();
  TextEditingController contactController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('Forget Password'),
        backgroundColor: AppStyle.appBarColor,
      ),

      body:  Container(
        padding: EdgeInsets.fromLTRB(0, 80, 0, 0),
        child:Form(
          key: formGlobalKey,
          child: Column(
            children: [


              Padding(
                padding: EdgeInsets.fromLTRB(30, 4, 30, 4),
                child: TextFormField(
                  //obscureText: true,
                  keyboardType:TextInputType.text,
                  controller: memberIdController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Member Id',
                    hintText: 'Enter Member Id',
                  ),

                    validator: (text) {
                      if (text != null) {

                      }
                      else
                        return 'Enter a valid email address';
                    }
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(30, 10, 30, 4),
                child: TextField(
                  // obscureText: true,
                  controller: contactController,
                  keyboardType:TextInputType.phone,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Contact',
                    hintText: 'Enter Contact',
                  ),
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                child: Text('Validate'),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => RestPasswordScreen(memberId: memberIdController.text)));
                },
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    padding: MaterialStateProperty.all(EdgeInsets.all(10)),
                    textStyle: MaterialStateProperty.all(TextStyle(fontSize: 20))),
              ),


            ],
          ),
        ),


      ),
    );
  }

}