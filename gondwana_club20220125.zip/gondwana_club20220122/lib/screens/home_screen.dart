import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:gondwana_club/screens/complaints.dart';
import 'package:gondwana_club/screens/eventslist.dart';
import 'package:gondwana_club/screens/helpdesk.dart';
import 'package:gondwana_club/screens/profile_screen.dart';
import 'package:gondwana_club/screens/splash_screen.dart';
import 'package:gondwana_club/screens/visitorinvitation.dart';
import '../global_style/style.dart';
import 'bookings_screen.dart';
import 'yourorder_screen.dart';
import 'memberdirectory_screen.dart';
import 'accounts_screen.dart';
import 'upcomingevents_screen.dart';
import 'privacy_screen.dart';
import 'affiliatedsclub_screen.dart';
import 'guestinvite_screen.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

class HomeScreen extends StatefulWidget {

  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final items = <Widget>[
      IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen())), icon: Icon(Icons.home_outlined, color: Colors.white)),
      IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen())), icon: Icon(Icons.shopping_bag_outlined, color: Colors.white)),
      IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen())), icon: Icon(Icons.add, color: Colors.white)),
      IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => Complaints())), icon: Icon(Icons.chat_bubble_outline_outlined, color: Colors.white)),
      IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => HelpDesk(title: 'Help Desk'))), icon: Icon(Icons.help_outline, color: Colors.white)),
    ];b
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('Home'),
        backgroundColor: AppStyle.appBarColor,
      ),
      bottomNavigationBar: CurvedNavigationBar(
        color: AppStyle.appBarColor,
        height: 55,
        index: index,
        items: items,
        backgroundColor: Colors.transparent,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
             DrawerHeader(
              decoration: BoxDecoration(
                color: AppStyle.appBarColor,
              ),
              child:Container(
                child: Row(
                  children: [
                    GestureDetector(
                      child: Container(
                        child: Icon(Icons.person,size: 40, color: Colors.white,),
                      ),
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
                      },
                    ),
                    SizedBox(width: 20),
                    GestureDetector(
                    child:Container(
                      child: Text('Mihir Naidu',style: TextStyle(color: Colors.white,fontSize: 20)),
                    ),
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
                    },
                  ),
                  ],
                ),
              ),
            ),
            ListTile(
              title: Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/upcoming.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Upcoming Events'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => EventsTimeline()));
              },
            ),
            ListTile(
              title: Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/booking2.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Bookings'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => BookingScreen()));
              },
            ),
            ListTile(
              title: Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/order-food.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Your Orders'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => YourOrderScreen()));
              },
            ),
            ListTile(
              title: Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/directory2.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Members Directory'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => MemberDirectoryScreen()));
              },
            ),
            ListTile(
              title: Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/accounting1.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Accounts'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => AccountsScreen()));
              },
            ),
            ListTile(
              title:Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/guest.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Guest Invite'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => guestinvite()));
              },
            ),
            ListTile(
              title: Container(
                width: 28,
                height: 28,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/affiliated.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Affiliated Clubs'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => AffiliatedClubScreen()));
              },
            ),
            ListTile(
              title: Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/security.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Privacy'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => PrivacyScreen()));
              },
            ),
            ListTile(
              title: Container(
                width: 30,
                height: 30,
                child: Row(
                  children: [
                    Container(
                      child: Image(
                        image:AssetImage('assets/icon-logout.png'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      child: Text('Logout'),
                    ),
                  ],
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPageScreen()));
              },
            ),
          ],
        ),
      ),

      body:  Container(
        //padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child:
        SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(
            child: Column(
              children: [

                /*====Search Bar========*/
                Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                  // width: double.infinity,
                  color: AppStyle.appBarColor,
                  child: TextField(
                    decoration: InputDecoration(
                      fillColor: Colors.greenAccent,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 1, color: AppStyle.appBarColor),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      hintText: 'Search for Members',focusColor: Colors.white,
                      hintStyle: TextStyle(fontSize: 18, color: Colors.white),
                      prefixIcon: Icon(Icons.search,color: Colors.white,),
                    ),
                  ),
                ),

                /*====Corousel- Image slider========*/
                SizedBox(height: 10),
                Container(
                  child: Card(
                    child: CarouselSlider(
                      items: [
                        Image(image: AssetImage('assets/hall1.jpg')),
                        Image(image: AssetImage('assets/hall2.jpg')),
                        Image(image: AssetImage('assets/hall3.jpg'))
                      ],
                      options:
                      CarouselOptions(
                        height: 180,
                        enlargeCenterPage: true,
                        autoPlay: true,
                        // aspectRatio: 16 / 9,
                        // autoPlayCurve: Curves.fastOutSlowIn,
                        // enableInfiniteScroll: true,
                        autoPlayAnimationDuration: Duration(milliseconds: 800),
                        viewportFraction: 0.8,
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 10),
                Container(
                  child: Card(
                    child: CarouselSlider(
                      items: [

                        Image(image: AssetImage('assets/hall1.jpg')),
                        Image(image: AssetImage('assets/hall2.jpg')),
                        Image(image: AssetImage('assets/hall3.jpg'))
                      ],
                      options:
                      CarouselOptions(
                        height: 180,
                        enlargeCenterPage: true,
                        autoPlay: true,
                        // aspectRatio: 16 / 9,
                        // autoPlayCurve: Curves.fastOutSlowIn,
                        // enableInfiniteScroll: true,
                        autoPlayAnimationDuration: Duration(milliseconds: 800),
                        viewportFraction: 0.8,
                      ),

                    ),
                  ),
                ),


                SizedBox(height: 10),
                Container(
                  child: Card(
                    child: CarouselSlider(
                      items: [
                        Image(image: AssetImage('assets/hall1.jpg')),
                        Image(image: AssetImage('assets/hall2.jpg')),
                        Image(image: AssetImage('assets/hall3.jpg'))
                      ],
                      options:
                      CarouselOptions(
                        height: 180,
                        enlargeCenterPage: true,
                        autoPlay: true,
                        // aspectRatio: 16 / 9,
                        // autoPlayCurve: Curves.fastOutSlowIn,
                        // enableInfiniteScroll: true,
                        autoPlayAnimationDuration: Duration(milliseconds: 800),
                        viewportFraction: 0.8,
                      ),

                    ),
                  ),
                ),
             ],
            ),
          ),
        ),
      ),


    );
  }

}