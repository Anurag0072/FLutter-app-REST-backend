import 'package:flutter/material.dart';
import 'package:gondwana_club/global_style/style.dart';

class AccountsScreen extends StatefulWidget {
  @override
  AccountsScreenState createState() => AccountsScreenState();
}

class AccountsScreenState extends State<AccountsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Accounts'),
        backgroundColor: AppStyle.appBarColor,
      ),
    );
  }

}