import 'package:flutter/material.dart';
import 'package:gondwana_club/global_style/style.dart';

class AffiliatedClubScreen extends StatefulWidget {
  @override
  AffiliatedClubScreenState createState() => AffiliatedClubScreenState();
}

class AffiliatedClubScreenState extends State<AffiliatedClubScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Affiliated Clubs'),
        backgroundColor: AppStyle.appBarColor,
      ),
    );
  }

}