import 'package:flutter/material.dart';
import 'package:gondwana_club/global_style/style.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: AppStyle.appBarColor),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text('Profile Details',style: TextStyle(color: AppStyle.appBarColor)),
          backgroundColor: Colors.transparent
      ),
      body: Container(
        padding: EdgeInsets.fromLTRB(6, 0, 6, 0),
        child: Column(
          children: [

            Container(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
              child:Stack(
                children: <Widget>[
                  CircleAvatar(
                    radius: 70,
                    child: ClipOval(child: Image.asset('assets/images/profileimg.jpeg',
                      height: 150, width: 150,
                      fit: BoxFit.cover,
                    ),
                    ),
                  ),
                  Positioned(
                    bottom: 1,
                    right: 1 ,
                    child: Container(
                      height: 40,
                      width: 40,
                      child: Icon(Icons.add_a_photo, color: Colors.white,),
                      decoration: BoxDecoration(
                          color: Colors.deepOrange,
                          borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                    ),)
                ],
              ),
            ),
            SizedBox(height: 8),
            /*===============Member Name & ID==================*/
            Container(
              width: 400,
              padding: EdgeInsets.fromLTRB(18, 2, 20, 0),
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54),
              ),
              child: Column(
                children: [
                  Container(
                    child: Text('Mihir Naidu',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20)),

                  ),
                  Container(
                    child:  Text('Membership Id = Mb1234',style: TextStyle()),
                  ),
                  SizedBox(height: 4),
                  Container(
                    child:  Divider(
                      indent: 0,
                      endIndent: 0,
                      color: Colors.black,
                    ),
                  ),
                  //SizedBox(height: 10),
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child: Text('Active',style: TextStyle(),),
                        ),
                        Container(
                          height: 64,
                          padding: EdgeInsets.fromLTRB(4, 0, 4, 8),
                          child: const VerticalDivider(
                            color: Colors.grey,
                            thickness: 1,
                            indent: 20,
                            endIndent: 10,
                            width: 20,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child: Text('27 years old'),
                        ),
                        Container(
                          height: 64,
                          padding: EdgeInsets.fromLTRB(4, 0, 4, 8),
                          child: const VerticalDivider(
                            color: Colors.grey,
                            thickness: 1,
                            indent: 20,
                            endIndent: 10,
                            width: 20,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child: Text('Male'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
             SizedBox(height: 20),
            /*===============Member Type==================*/
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
              child:  Text('Membership Type',style: TextStyle()),
            ),
            SizedBox(height: 10),
            Container(
              width: 400,
              padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black54),
              ),
              child: Column(
                children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(110, 6, 110, 4),
                    color: AppStyle.appBarColor,
                    child: Column(
                      children: [
                        Container(
                          child:  Text('Gold Membership',style: TextStyle(color: Colors.white ,fontWeight: FontWeight.bold,fontSize: 20)),
                        ),
                        Container(
                          child:  Text('Expired on : 31 Aug 2022',style: TextStyle(color: Colors.white)),
                        ),
                      ],
                    ),
                  ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      Container(
                        child: Column(
                          children: [
                            Container(
                              child:  Text('Purchased on',style: TextStyle()),
                            ),
                            SizedBox(height: 4),
                            Container(
                              child:  Text('31-Aug-2022',style: TextStyle(fontWeight: FontWeight.bold)),
                            ),
                          ],
                        )
                      ),
                      Container(
                        height: 60,
                        padding: EdgeInsets.fromLTRB(4, 0, 4, 8),
                        child: const VerticalDivider(
                          color: Colors.grey,
                          thickness: 1,
                          indent: 20,
                          endIndent: 10,
                          width: 20,
                        ),
                      ),
                      Container(
                          child: Column(
                            children: [
                              Container(
                                child:  Text('Expires on',style: TextStyle()),
                              ),
                              SizedBox(height: 4),
                              Container(
                                child:  Text('31-Aug-2025',style: TextStyle(fontWeight: FontWeight.bold)),
                              ),
                            ],
                          )
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),
            /*===============Contact Details==================*/

            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.fromLTRB(10, 8, 0, 0),
              child:  Text('Details',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            ),
            Divider(),
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.fromLTRB(10, 8, 0, 0),
              child: Row(
                //mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Icon(Icons.email),
                  ),
                  SizedBox(width: 10),
                  Container(
                    child: Text('mihirnaidu@gmail.com'),
                  ),

                ],
              ),
            ),

            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.fromLTRB(10, 8, 0, 0),
              child: Row(
                // mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Icon(Icons.call),
                  ),
                  SizedBox(width: 10),
                  Container(
                    child: Text('9865321452'),
                  ),
                ],
              ),
            ),

            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.fromLTRB(10, 8, 0, 0),
              child: Row(
                // mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Icon(Icons.location_city),
                  ),
                  SizedBox(width: 10),
                  Container(
                    child: Text('Nagpur'),
                  ),
                ],
              ),
            ),

            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.fromLTRB(10, 8, 0, 0),
              child: Row(
                // mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Icon(Icons.web),
                  ),
                  SizedBox(width: 10),
                  Container(
                    child: Text('https://brilect.in'),
                  ),
                ],
              ),
            ),


          ],
        ),
      ),
    );

  }
}