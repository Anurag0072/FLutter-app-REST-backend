import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import '../global_style/style.dart';
import 'splash_screen.dart';

class RestPasswordScreen extends StatefulWidget {
  String memberId;
  RestPasswordScreen({required this.memberId});

  @override
  RestPasswordState createState() => RestPasswordState();
}

class RestPasswordState extends State<RestPasswordScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('Reset Password'),
        backgroundColor: AppStyle.appBarColor,
      ),

      body:  Container(
        padding: EdgeInsets.fromLTRB(0, 80, 0, 0),
        child: Column(
          children: [

            Container(
              padding: EdgeInsets.fromLTRB(30, 0, 0, 0),
              alignment: Alignment.centerLeft,
              child: Html(data: 'MemberId: <b>${widget.memberId}</b>'),
             // Text('MemberId: '+widget.memberId, style: TextStyle(fontWeight: FontWeight.bold),),
            ),
            SizedBox(height: 10),
            Padding(
              padding: EdgeInsets.fromLTRB(30, 4, 30, 4),
              child: TextField(
                obscureText: true,
                keyboardType:TextInputType.text,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Password',
                  hintText: 'Enter Password',
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.fromLTRB(30, 10, 30, 4),
              child: TextField(
                obscureText: true,
                keyboardType:TextInputType.text,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Confirm Password',
                  hintText: 'Enter Confirm Password',
                ),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              child: Text('Submit'),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => LoginPageScreen()));
              },
              style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.blue),
                  padding: MaterialStateProperty.all(EdgeInsets.all(10)),
                  textStyle: MaterialStateProperty.all(TextStyle(fontSize: 20))),
            ),


          ],
        ),

      ),
    );
  }

}