
import 'dart:ui';

import 'package:flutter/material.dart';

class AppStyle {

  static Color appBarColor = Color(0xff3EA99F);
  static final Color primaryColor = Colors.blue;
  static final Color scaffoldBackgroundColor = Color.fromRGBO(245, 247, 249, 1);
}